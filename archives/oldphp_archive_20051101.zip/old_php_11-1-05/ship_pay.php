<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Art by Marilyn Speck Ballard | Shipping and Payment</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>

</head>
<body>
<div align="center"> 


		<tr> 
			<td colspan="6" class="main"> <table border="0">
					<tr> 
						<td width="20%" align="center">&nbsp; </td>
						<td width="60%" class="mainText"> <strong>Payment &amp; Shipping Information</strong> 
							<p> After ordering, you'll receive a "Request-for-money" e-mail 
								from PayPal. It will include links to click for payment. After 
								clearing, shipment will be mailed. </p>
							<p>Shipping method: USPS Priority Delivery for deliveries within the USA <strong>PRINTS:</strong> $4.98</p>
							<p>For <strong>Originals</strong>, <strong>multiple item</strong> 
								orders and <strong>shipments outside the USA</strong>, please contact <a href="mailto:msballard1@gmail.com" style="color:blue">Marilyn</a> 
								for shipping rates.</p>
							<p>Missouri residents pay 5.825% sales tax.</p></td>
						<td width="20%" align="center">&nbsp; </td>
					</tr>
				</table></td>
		</tr>
<?php

include('include/footer.inc');

?>
</div>
</body>
</html>
