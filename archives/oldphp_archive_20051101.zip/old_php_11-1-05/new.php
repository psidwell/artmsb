<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Art by Marilyn Speck Ballard | New Pieces</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>

		<tr> 
			<td colspan="6" class="main" align="center"> <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
					<tr> 
						<td>&nbsp; </td>
					</tr>
					<tr>
						<td align="center"><a href="javascript:void(window.open('images/new/farmhouse.jpg', 'NEW', 'width=610,height=320'))"><img src="images/new/t_farmhouse.jpg" width="300" height="150" alt="Neighbor's Farm. Copyright &copy; 2005. Marilyn Speck Ballard." border="0" /></a><br />

							<font face="Arial, Helvetica, sans-serif" size="1"><em>Neighbor's Farm</em>&nbsp; &nbsp;<a href="gallery.php" style="color:blue;">Gallery</a></font>
							<p>&nbsp; </p></td></tr>
					<tr> 
						<td align="center"><a href="javascript:void(window.open('images/new/catholic_chapel.jpg', 'NEW', 'width=500,height=644'))"><img src="images/new/t_catholic_chapel.jpg" width="300" height="386" alt="Catholic Chapel, USMA, West Point, NY.  Copyright &copy; 2004 - 2005. Marilyn Speck Ballard." border="0" /></a><br /> 
							<font face="Arial, Helvetica, sans-serif" size="1"><em>Catholic Chapel, USMA, West Point, NY.</em>&nbsp &nbsp;<a href="gallery.php" style="color:blue;">BUY</a></font> 
							<p>&nbsp; </p></td></tr>
					<tr> 
						<td align="center"><a href="javascript:void(window.open('images/new/swift_stream.jpg', 'NEW', 'width=620,height=500'))"><img src="images/new/t_swift_stream.jpg" width="300" height="236" alt="After the Rain.  Copyright &copy; 2004 - 2005. Marilyn Speck Ballard." border="0" /></a><br /> 
							<font face="Arial, Helvetica, sans-serif" size="1"><em>After the Rain.</em>&nbsp &nbsp;<a href="gallery.php" style="color:blue;">BUY</a></font> 
							<p>&nbsp; </p></td></tr>
					<tr> 
						<td align="center"><a href="javascript:void(window.open('images/new/chief_ten_feathers.jpg', 'NEW', 'width=435,height=550'))"><img src="images/new/t_chief_ten_feathers.jpg" width="300" height="422" alt="Gateway Arch.  Copyright &copy; 2004 - 2005. Marilyn Speck Ballard." border="0" /></a><br /> 
							<font face="Arial, Helvetica, sans-serif" size="1"><em>Chief Ten Feathers.</em>&nbsp &nbsp;<a href="gallery.php" style="color:blue;">BUY</a></font> 
							<p>&nbsp; </p></td></tr>
					<tr> 
				</table></td>
		</tr>
<?php

include('include/footer.inc');

?>

</div>
</body>
</html>
