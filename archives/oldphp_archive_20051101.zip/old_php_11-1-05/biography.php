<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Art by Marilyn Speck Ballard | Biography</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>
		<tr> 
			<td colspan="6" class="main" align="center"> <table border="0" width="100%">
					<tr> 
						<td width="20%" align="center" valign="top"> <table width="80%" cellpadding="2" cellspacing="0" border="0" align="center" valign="top">
								<tr> 
									<td align="center"><img src="images/new_family/marilyn2.jpg" border="0"> 
									</td>
								</tr>
								<tr> 
									<td align="center"><a href="images/family/welcome.jpg" target="_blank"><img src="images/new_family/welcome.jpg" border="0"></a> 
									</td>
								</tr>
								<tr> 
									<td align="center"><a href="images/family/flowers_along_the_drive.jpg" target="_blank"><img src="images/new_family/flowers_along_the_drive.jpg" border="0"></a> 
									</td>
								</tr>
								<tr> 
									<td align="center"><a href="images/family/horse_in_pasture.jpg" target="_blank"><img src="images/new_family/horses_in_pasture.jpg" border="0"></a> 
									</td>
								</tr>
							</table></td>
						<td width="60%" class="mainText" valign="top"> <p><strong>Marilyn 
								S. Ballard, Artist</strong></p>
							<p>Marilyn is a graduate of Southeast Missouri State University 
								with a B.A. degree in Art and Elementary Education. She completed 
								post-graduate studies in Art at SEMO University and Kansas University. 
								She is now a retired art teacher and grandmother. </p>
							<p>Marilyn is currently teaching private art lessons and now paints 
								for fun, friends and a new web site, <a href="../index.htm" style="color: blue">artmsb.com</a>. 
								She and her husband, Larry, are a team on their acreage outside 
								St. Louis where they enjoy raising cattle, gardening, cooking, 
								and playing with grandkids. </p>
							<p>The farm and grandchildren are primary subjects of her paintings. 
								She still teaches private classes in Watercolors, Acrylics, and 
								Pottery, and enjoys participating in various art shows. Lake Saint 
								Louis Art Association, and an exciting artist�s web site, <a href="http://www.wetcanvas.com" style="color: blue">WetCanvas.com</a>, 
								made up of over 47,000 members.</p></td>
						<td width="20%" align="center" valign="top"> <table width="80%" cellpadding="2" cellspacing="0" align="center" valign="top" border="0">
								<tr> 
									<td align="center"><a href="images/family/steers_lined_up.jpg" target="_blank"><img src="images/new_family/steers_lined_up.jpg" border="0"></a> 
									</td>
								</tr>
								<tr> 
									<td align="center"><a href="images/family/marilyn-n-larry_fall03.jpg" target="_blank"><img src="images/new_family/marilyn-n-larry_fall03.jpg" border="0"></a> 
									</td>
								</tr>
								<tr> 
									<td align="center"><a href="images/family/crisp_morning04.jpg" target="_blank"><img src="images/new_family/crisp_morning04.jpg" border="0"></a> 
									</td>
								</tr>
								<tr> 
									<td align="center"><a href="images/family/kids_on_tractor.jpg" target="_blank"><img src="images/new_family/kids_on_tractor.jpg" border="0"></a> 
									</td>
								</tr>
							</table></td>
					</tr>
				</table></tr>
<?php

include('include/footer.inc');

?>
</div>
</body>
</html>
