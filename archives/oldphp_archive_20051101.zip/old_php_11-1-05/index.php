<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>

<title>Art by Marilyn Speck Ballard | Home</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>
<script language="JavaScript1.2" src="scripts/slideshow.js" type="text/javascript"></script>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>

		<tr> 
			<td colspan="6" class="main"> <table border="0" width="100%">
					<tr> 
						<td rowspan="2" width="25%" align="center"> <table border="0" width="90%" cellpadding="2" cellspacing="0" align="center" style="border:solid #CCCCCC 1px;">
								<tr> 
									<td bgcolor="#EEEEEE" style="font:8pt,sans-serif;font-weight:bold;text-align:center;border-bottom:solid #CCCCCC 1px">Slideshow</td>
								</tr>
								<tr>
									<td align="center"> 
<?php

include('include/slideshow.inc');

?>
									</td>
								</tr>
							</table>
							
							
							
							</td>
						<td rowspan="2" width="50%" class="mainText"> 
							
							<!-- EDIT TEXT HERE -->
							<p><strong>Originals, Prints and Murals:<br />
								</strong> <em>Watercolor, Acrylics, Pencil, Pen &amp; Ink, Pastels. 
								</em></p>
							<p>Each print is made on acid free paper, matted and signed by the 
								artist, suitable for placing in a ready-made frame. Keep prints 
								out of direct sunlight and away from dampness.</p>
							<p>Special orders of original paintings are available in Watercolors 
								and Acrylics by commission. Bulk rates for greeting
								cards are also available. Suggestions for subjects are welcome. 
								Please email me at <a href="mailto:msballard@centurytel.net" style="color: blue">msballard@centurytel.net</a> 
							</p>
							<p>Images on this web site are of low resolution and NOT for reproduction. 
								The prints have sharper details.</p>
							<p>Thank you for visiting!</p>
							<p>&nbsp; </p>
							<!-- END EDIT TEXT --></td>

							
						<td width="25%" align="center"> <table border="0" width="90%" cellpadding="2" cellspacing="0" align="center" style="border:solid #CCCCCC 1px;">
								<tr> 
									<td bgcolor="#EEEEEE" style="font:8pt,sans-serif;font-weight:bold;text-align:center;border-bottom:solid #CCCCCC 1px">Featured 
										Piece</td>
								</tr>
								<tr> 
									<td align="center"> 
									
									<!-- Featured image random script -->
									<script language="JavaScript" type="text/javascript"><!--
									
									featuredImage();
									
									// -->
									</script>
									<!-- End random featured image script -->
									
									<!-- Old feature image tag -->
									
									<!--<a href="javascript:void(window.open('images/large/22.jpg', 'Image', 'width=625,height=500'))">
									<img src="images/swift_stream.jpg" width="125" align="center" border="0" name="After-the-Rain" alt="After the Rain. 
									Copyright &copy; 2004 - 2005. Marilyn Speck Ballard." /></a>
									</td>
								</tr>
								<tr> 
									<td> <p align="center" style="font:8pt,sans-serif;"><em>After the Rain</em></td> -->
									
									<!-- End old featured image tag -->
									
								</tr>
							</table></td>
					</tr>
					<tr> 
						<td align="center" valign="top"><table border="0" width="90%" cellpadding="2" cellspacing="0" align="center" style="border:solid #CCCCCC 1px;">
								<tr> 
									<td bgcolor="#EEEEEE" style="font:8pt,sans-serif;font-weight:bold;text-align:center;border-bottom:solid #CCCCCC 1px">	Design Your Own<br />Greeting Cards</td>
									</tr>
									<tr>
										<td style="font:8pt,sans-serif;">Discover how Marilyn applies her skills as an artist to produce fine Greeting and Christmas Cards. <a href="javascript:void(getArticle());" onMouseOver="window.status='Design Your Own Christmas Cards';return true" onMouseOut="window.status='';return true" style="color:blue">Click here</a>.</td>
									</tr>
								</table>
							</td>
					</tr>
				</table></td>
		</tr>
<?php

include('include/footer.inc');

?>
	<table width="750" border="0">
		<tr> 
			<td width="100%" align="center"> 
				<!-- Start of StatCounter Code -->
				<script type="text/javascript" language="javascript">
var sc_project=335942; 
var sc_partition=1; 
</script> <script type="text/javascript" language="javascript" src="http://www.statcounter.com/counter/counter.js"></script> 
				<noscript>
				<a href="http://www.statcounter.com/free_web_stats.html" target="_blank"><img  src="http://c2.statcounter.com/counter.php?sc_project=335942&amp;java=0" alt="free stats" border="0"></a> 
				</noscript> 
				<!-- End of StatCounter Code -->
			</td>
		</tr>
	</table>
</div>
</body>
</html>
