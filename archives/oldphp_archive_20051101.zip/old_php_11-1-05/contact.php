<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Art by Marilyn Speck Ballard | Contact</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>

		<tr> 
			<td colspan="6" class="main"> <table border="0" width="100%">
					<tr> 
						<td width="25%" align="center">&nbsp; </td>
						<td width="50%" class="mainText" style="padding-left:25px;"> <p><strong>Art by Marilyn Speck 
								Ballard</strong><br />
								2894 Jackson Rd.<br />
								Wentzville, MO 63385-4205 USA</p>
							<p>Phone: (636) 673-0022<br />
								Fax: (636) 673-0022 <br/>
								E-mail: <a href="mailto:msballard1@gmail.com" style="color: blue">msballard@centurytel.net</a></p>
							<p><a href="../ship_pay.htm" style="color:blue">Shipping & Payment 
								Information</a></p></td>
						<td width="25%" align="center" valign="top"> <table border="0" width="90%" cellpadding="2" cellspacing="0" align="center" style="border:solid #CCCCCC 1px;">
								<tr> 
									<td style="background-color:EEEEEE;font:8pt,sans-serif,bold;text-align:center;border-bottom:solid #CCCCCC 1px"><strong>Community</strong></td>
								</tr>
								<tr> 
									<td style="text-align:left;padding-left:20px;"><a href="http://www.wetcanvas.com/Community/gman/" style="font:8pt,sans-serif;color:blue;">WetCanvas.com</a></td></tr><tr><td style="text-align:left;padding-left:20px;"><a href="http://www.art-agent.com/artist_info.php?userid=35425" style="font:8pt,sans-serif;color:blue;">Art-Agent.com</a></td>
								</tr>
							</table></td>
					</tr>
				</table></td>
		</tr>

<?php

include('include/footer.inc');

?>


</div>
</body>
</html>
