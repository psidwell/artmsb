<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Art by Marilyn Speck Ballard | Gallery</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>

		<tr> 
			<td colspan="6" class="main"> <table width="100%">
					<tr> 
						<td align="center"> <table width="90%" cellspacing="0" cellpadding="0" border="0" class="mainText">
								<tr> 
									<td colspan="3"> <p><strong>Gallery</strong></p>
										<p><font size="2">Prints are matted and ready for framing 
											behind glass. These will fit a standard 11x14 frame. Keep 
											prints out of direct sunlight and away from dampness.</font></p>
										<p><font size="2">Click <strong><a href="ship_pay.htm" style="color:blue">HERE</a></strong> 
											for <strong>Shipping &amp; Payment Information.</strong></font></p>
										<p><font size="1">Click on the images to see a larger version.</font></p></td>
									<td valign="middle">
										<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard1@gmail.com">
											<input type="image" src="https://www.paypal.com/images/view_cart.gif" border="0" name="submit" 
											alt="Make payments with PayPal - it's fast, free and secure!" align="right">
											<input type="hidden" name="display" value="1">
										</form>
									</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Neighbor's Farm</font></strong><br /> <font size="2">Acrylic - Original<br /></font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/27_L.jpg', 'Gallery', 'width=625,height=310'))"><img src="images/gallery/27.jpg" align="center" width="150" border="0"></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="center" class="leftSideCell"><strong>Original (Acrylic) 24x48
										<font color="#000099"></font></strong> 
										<ul style="text-align:center;">
											<li><font size="2">NOT FOR SALE. This is an example of commssioned work. Contact <a href="mailto:msballard@centurytel.net" style="color:blue">Marilyn</a> for further details.</font></li>
										</ul></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Cadets Walking by Catholic Chapel, USMA, West Point, N.Y.
									</font></strong><br /> <font size="2">Acrylic - Original<br /></font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/26_L.jpg', 'Gallery', 'width=525,height=650'))"><img src="images/gallery/26.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="center" class="leftSideCell">
										<table width="100%" cellspacing="0">
											<tr>
												<td align="right" style="font:9pt verdana;"><strong>Original (Acrylic)</strong>:
											</td>
												<td align="center" colspan="3" style="font:9pt verdana;">Contact 
												<a href="mailto:msballard@centurytel.net" style="color:blue">Marilyn</a> 
													for pricing and shipping information.</td>
											</tr>

											<tr>
												<td align="right" style="font:9pt verdana;"><strong>Print 8x10</strong></td>
												<td align="center" style="font:9pt verdana;"><strong><font color="#000099">$20.00</font></strong></td>
												<td colspan="2">&nbsp;
													<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
														<input type="hidden" name="cmd" value="_cart">
														<input type="hidden" name="business" value="msballard1@gmail.com">
														<input type="hidden" name="item_name" value="Cadets Walking by Catholic Chapel, Print 8x10">
														<input type="hidden" name="item_number" value="1070_MD">
														<input type="hidden" name="currency_code" value="USD">
														<input type="hidden" name="amount" value="20.00">
														<input type="hidden" name="shipping" value="4.98">
														<input type="hidden" name="no_note" value="1">
														<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
														<input type="hidden" name="add" value="1">
													</form></td>
												<!--

												<td height="50">&nbsp;
													<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
														<input type="hidden" name="cmd" value="_cart">
														<input type="hidden" name="business" value="msballard1@gmail.com">
														<input type="image" src="https://www.paypal.com/images/view_cart.gif" border="0" name="submit" 
														alt="Make payments with PayPal - it's fast, free and secure!">
														<input type="hidden" name="display" value="1">
													</form></td>
												-->
											</tr>
										</table>
									</td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Chief Ten Feathers: Face of a Proud People</font></strong><br /> <font size="2">Oil Pastel - Original<br /></font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/24_L.jpg', 'Gallery', 'width=415,height=545'))"><img src="images/gallery/24.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="center" class="leftSideCell"><strong>Original 
										(Oil Pastel) 21x26 Double Matted and Framed<font color="#000099"></font></strong> 
										<ul style="text-align:center;">
											<li><font size="2">Contact <a href="mailto:msballard@centurytel.net" style="color:blue">Marilyn</a> 
												for pricing and shipping information.</font></li>
										</ul></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Pleasant 
										Memories</font></strong><br /> <font size="2">Acrylic - Original</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/19_L.jpg', 'Gallery', 'width=820,height=650'))"><img src="images/gallery/19.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="center" class="leftSideCell"><strong>Original 
										(Acrylic) 16x20 <font color="#000099"></font></strong> 
										<ul style="text-align:center;">
											<li><font size="2">Contact <a href="mailto:msballard1@gmail.com" style="color:blue">Marilyn</a> 
												for pricing and shipping information.</font></li>
										</ul></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Nevermore</font></strong><br /> 
										<font size="2">Acrylic - Original</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/18_L.jpg', 'Gallery', 'width=300,height=600'))"><img src="images/gallery/18.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="left" class="leftSideCell"> 
										<p>&nbsp;</p>
										<p style="text-align:center"><strong>Original (Acrylic) 23x48 
											<font color="#000099"></font></strong> 
										<ul style="text-align:center;">
											<li><font size="2">Contact <a href="mailto:msballard1@gmail.com" style="color:blue">Marilyn</a> 
												for pricing and shipping information.</font></li>
										</ul></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Lusk 
										Reservoir, USMA, West Point, NY</font></strong><br /> <font size="2">Acrylic 
										- Print</font></td>
									<td rowspan="5" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/21_L.jpg', 'Gallery', 'width=500,height=400'))"><img src="images/gallery/21.jpg" align="center" border="0" alt="Most cadets will remember this view of Lusk Reservoir on their steep walk to home football games, after ascending the seemingly thousand-step climb along the Protestant Chapel. Or perhaps it was the beginning or end of a beautiful stroll around the waterside with friends or family.  This print of an acrylic painting is on acid-free paper, and captures the beautiful convergence of emerging fall colors, wildlife, water, and granite that is a hallmark to the Hudson Highlands"></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="left" class="leftSideCell"> 
										<p>&nbsp;</p>
										<p style="text-align:center"><strong>Original (Acrylic) 11x14 
											</strong> 
											<!--
									<font color="#000099">$360.00</font></strong>
									<ul style="text-align:center;"><li><font size="2">Contact 
									<a href="mailto:msballard1@gmail.com" style="color:blue">Marilyn</a> 
										for shipping information.</font></li></ul>-->
										<ul style="text-align:center;">
											<li><font size="2">Unavailable at this time.</font></li>
										</ul></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Lusk Reservoir, Print 8x10">
											<input type="hidden" name="item_number" value="1055_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td colspan="3" class="leftSideCell"> <p style="text-align:left;padding:25px;font-size:8pt;"><strong>Description:</strong><br />
											Most cadets will remember this view of Lusk Reservoir on 
											their steep walk to home football games, after ascending 
											the seemingly thousand-step climb along the Protestant Chapel. 
											Or perhaps it was the beginning or end of a beautiful stroll 
											around the waterside with friends or family. This print 
											of an acrylic painting is on acid-free paper, and captures 
											the beautiful convergence of emerging fall colors, wildlife, 
											water, and granite that is a hallmark to the Hudson Highlands</p></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Walking 
										to Michie Stadium, USMA, West Point, NY</font></strong><br /> 
										<font size="2">Acrylic - Print</font></td>
									<td rowspan="5" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/22_L.jpg', 'Gallery', 'width=490,height=380'))"><img src="images/gallery/22.jpg" align="center" border="0" alt="Join cadets, with family and friends, on a stroll along scenic Mills Road in this Acrylic depiction of a well-known but rarely captured scene of the United States Military Academy at West Point.  A lovely walk to sports events in Michie Stadium and Lusk Reservoir, this long but gently sloping path evokes memories, both recent and afar, with its simple, timeless beauty."></a></td>
								</tr>
								<tr> 
									<td colspan="3" height="50" align="left" class="leftSideCell"> 
										<p>&nbsp;</p>
										<p style="text-align:center;"><strong>Original (Acrylic) 12x16 
											</strong> 
											<!--
									<font color="#000099">$360.00</font></strong>
									<ul style="text-align:center;"><li><font size="2">Contact 
									<a href="mailto:msballard1@gmail.com" style="color:blue">Marilyn</a> 
										for shipping information.</font></li></ul>-->
										<ul style="text-align:center;">
											<li><font size="2">Unavailable at this time.</font></li>
										</ul></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Walking to Michie Stadium, Print 8x10">
											<input type="hidden" name="item_number" value="1055_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td colspan="3" class="leftSideCell"><p style="text-align:left;padding:25px;font-size:8pt;"><strong>Description:</strong><br />
											Join cadets, with family and friends, on a stroll along 
											scenic Mills Road in this Acrylic depiction of a well-known 
											but rarely captured scenes of the United States Military 
											Academy at West Point. A lovely walk to sports events in 
											Michie Stadium and Lusk Reservoir, this long but gently 
											sloping path evokes memories, both recent and afar, with 
											its simple, timeless beauty.</p></td>
								</tr>
								<tr> 
									<td height="25" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td height="50" width="75%" colspan="3" class="topOfCell"><strong><font color="#000066">South 
										Pasture</font></strong><br /> <font size="2">Watercolor - 
										Print</font></td>
									<td rowspan="3" align="center" class="imageCell"><a href="javascript:void(window.open('images/gallery/14_L.jpg', 'Gallery', 'width=475,height=410'))"><img 
src="images/gallery/14.jpg" align="center" border="0"></a>&nbsp; </td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="South Pasture, Print 8x10">
											<input type="hidden" name="item_number" value="1038_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="topOfCell"><strong><font color="#000066">Cardinals 
										Under Oak</font></strong><br /> <font size="2">Watercolor 
										- Print</font><strong></strong><br /> </td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/5_L.jpg', 'Gallery', 'width=460,height=325'))"><img 
src="images/gallery/5.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10<font color="#000099"> 
										</font></strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Cardinals Under Oak, Print 8x10">
											<input type="hidden" name="item_number" value="1040_M">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Cookin' 
										For This Family Jus' Wears Me Out</font></strong><br /> <font size="2">Watercolor 
										- Print</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/6_L.jpg', 'Gallery', 'width=400,height=525'))"><img 
src="images/gallery/6.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Cookin For This Family Jus Wears Me Out, Print 8x10">
											<input type="hidden" name="item_number" value="1048_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Sandbox</font></strong><br /> 
										<font size="2">Watercolor - Print</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/13_L.jpg', 'Gallery', 'width=400,height=520'))"><img 
src="images/gallery/13.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Sandbox, Print 8x10">
											<input type="hidden" name="item_number" value="1049_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Cardinal 
										in Juniper Tree</font></strong><br /> <font size="2">Watercolor 
										- Print</font><strong></strong><br /> </td>
									<td rowspan="4" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/4_L.jpg', 'Gallery', 'width=385,height=520'))"><img 
src="images/gallery/4.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Cardinal in Juniper Tree, Print 8x10">
											<input type="hidden" name="item_number" value="1042_M">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 11x14</strong></td>
									<td align="center"><font color="#000099"><strong>$30.00</strong></font></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Cardinal in Juniper Tree, Print 11x14">
											<input type="hidden" name="item_number" value="1042_L">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="30.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Walking 
										With Friends</font></strong><br /> <font size="2">Watercolor 
										- Print</font><strong></strong><br /> </td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/15_L.jpg', 'Gallery', 'width=515,height=400'))"><img 
src="images/gallery/15.jpg" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Walking With Friends, Print 8x10">
											<input type="hidden" name="item_number" value="1043_M">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Parkbench 
										(Count the Birds)</font></strong><br /> <font size="2">Watercolor 
										- Print</font><strong></strong><br /> </td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/11_L.jpg', 'Gallery', 'width=540,height=400'))"><img 
src="images/gallery/11.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Parkbench (Count the Birds), Print 8x10">
											<input type="hidden" name="item_number" value="1044_M">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td width="75%"  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Cannon 
										at Trophy Point, West Point, NY, overlooking Hudson River</font></strong><br /> 
										<font size="2">Watercolor - Print</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/3_L.jpg', 'Gallery', 'width=660,height=500'))"><img 
src="images/gallery/3.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Cannon at Trophy Point, West Point, NY, Print 8x10">
											<input type="hidden" name="item_number" value="1045_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Miss 
										Prissy</font></strong><br /> <font size="2">Watercolor - Print</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/9_L.jpg', 'Gallery', 'width=600,height=450'))"><img src="images/gallery/9.jpg" align="center" border="0"></a> 
									</td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Miss Prissy, Print 8x10">
											<input type="hidden" name="item_number" value="1053_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Early 
										Fall, Hudson River, West Point, NY</font></strong><br /> <font size="2">Watercolor 
										- Print</font></td>
									<td rowspan="3" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/20_L.jpg', 'Gallery', 'width=720,height=470'))"><img 
src="images/gallery/20.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Early Fall, Hudson River, West Point, N.Y, Print 8x10">
											<input type="hidden" name="item_number" value="1054_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">New 
										Kid on the Block</font></strong><br /> <font size="2">Watercolor 
										- Print</font></td>
									<td rowspan="3" align="center" class="imageBottomCell"><a 
href="javascript:void(window.open('images/gallery/10_L.jpg', 'Gallery', 'width=370,height=270'))"><img src="images/gallery/10.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="New Kid on the Block, Print 8x10">
											<input type="hidden" name="item_number" value="1055_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Battle 
										Monument, West Point, NY</font></strong><br /> <font size="2">Pencil, 
										registered in Library of Congress - Print</font></td>
									<td rowspan="4" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/1_L.jpg', 'Gallery', 'width=400,height=500'))"><img 
src="images/gallery/1.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Battle Monument, West Point, NY, Print 8x10">
											<input type="hidden" name="item_number" value="1046_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<td colspan="3" class="leftSideCell"> <p style="text-align:left;padding:25px;font-size:8pt;"><strong>Description:</strong><br />
										With Fame perched atop this Civil War memorial on Trophy Point, 
										Battle Monument is seen in its stark beauty in this pencil 
										rendition of one of West Point's more famous monuments. The 
										illustrated area is roughly 8" by 10" with the outer edge 
										being roughly 11" by 13". Drawn by a mother of a graduate, 
										this deep gray and white print on acid-free paper makes for 
										a special gift or nice addition to one's own collection.</p></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Pershing 
										Sally Port, West Point, NY</font></strong><br /> <font size="2">Pencil, 
										registered in Library of Congress - Print</font></td>
									<td rowspan="4" align="center" class="imageCell"><a 
href="javascript:void(window.open('images/gallery/16_L.jpg', 'Gallery', 'width=200,height=250'))"><img 
src="images/gallery/16.jpg" align="center" border="0"></a></td>
								</tr>
								<tr> 
									<td align="right" class="leftSideCell"><strong>Print 8x10</strong></td>
									<td align="center"><strong><font color="#000099">$20.00</font></strong></td>
									<td>&nbsp; <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post">
											<input type="hidden" name="cmd" value="_cart">
											<input type="hidden" name="business" value="msballard@centurytel.net">
											<input type="hidden" name="item_name" value="Pershing Sally Port, West Point, NY, Print 8x10">
											<input type="hidden" name="item_number" value="1047_MD">
											<input type="hidden" name="currency_code" value="USD">
											<input type="hidden" name="lc" value="US">
											<input type="hidden" name="amount" value="20.00">
											<input type="hidden" name="shipping" value="4.98">
											<input type="hidden" name="no_note" value="1">
											<input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but22.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!">
											<input type="hidden" name="add" value="1">
										</form></td>
								</tr>
								<tr> 
									<td colspan="3" class="leftSideCell"> <p style="text-align:left;padding:25px;font-size:8pt;"><strong>Description:</strong><br />
											This pencil drawing print of West Point captures the timeless 
											activity of Central Area that has changed little over the 
											years. The perspective is from the sally port of Pershing 
											Barracks, and looks across the Area to Bradley Barracks 
											with the Protestant Chapel rising in the background. The 
											illustrated area is roughly 8" by 10" with the outer edge 
											being roughly 11" by 13". Drawn by a mother of a graduate, 
											this black and white print on acid-free paper makes for 
											a special gift or nice addition to one's own collection.</p></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftSideCell">&nbsp;</td>
								</tr>
								<tr> 
									<td  height="50"  colspan="3" class="topOfCell"><strong><font color="#000066">Rabbit 
										in Hiding</font></strong><br /> <font size="2">Pen &amp; Ink 
										- Print</font></td>
									<td rowspan="3" align="center" class="imageBottomCell"><a href="javascript:void(window.open('images/gallery/7_L.jpg', 'Gallery', 'width=200,height=250'))"><img src="images/gallery/7.jpg" align="center" border="0"></a></td>
								</tr>
								<!-- NO PRICING AVAILABLE AT THIS TIME (JULY 2ND, 2004) -->
								<tr> 
									<td colspan="3" align="center" class="leftSideCell"><font size="2">Contact 
										<a href="mailto:msballard@centurytel.net" style="color:blue">Marilyn</a> 
										for pricing and availability.</font></td>
								</tr>
								<tr> 
									<td height="50" colspan="3" class="leftBottomCell">&nbsp;</td>
								</tr>
								<tr> 
									<td height="50" colspan="4" align="right" valign="middle">&nbsp; 
										<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post" />
											<input type="hidden" name="cmd" value="_cart" />
											<input type="hidden" name="business" value="msballard@centurytel.net" />
											<input type="image" src="https://www.paypal.com/images/view_cart.gif" border="0" name="submit" 
											alt="Make payments with PayPal - it's fast, free and secure!" align="right" />
											<input type="hidden" name="display" value="1" />
										</form><br /></td>
								</tr>
							</table></td>
					</tr>
				</table>

<?php

include('include/footer.inc');

?>

</div>
</body>
</html>
