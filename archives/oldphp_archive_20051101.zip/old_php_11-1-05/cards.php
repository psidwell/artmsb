<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Art by Marilyn Speck Ballard | Greeting Cards</title>

<?php

include('include/meta.inc');

include('include/scripts.inc');

?>

</head>
<body>
<div align="center"> 

<?php

include('include/banner.inc');

include('include/navigation.inc');

?>

		<tr>
			<td colspan="6" class="main" align="center"> <table border="0" width="95%" height="100%">
					<tr> 
						<td colspan="2" align="left" class="mainText"><p><strong>Snow Scene/Christmas 
								Cards</strong></p>
							<p>To order greeting cards, determine the quantity and style of 
								card you would like from below. Determine any additional options 
								you would like (i.e. - colored text for verses). When you have 
								your order selected contact <a href="mailto:msballard1@gmail.com?Subject=Christmas Card Order" style="color:blue">Marilyn</a> 
								with all of the information. If you have any questions about what 
								to do, feel free to contact <a href="mailto:msballard1@gmail.com?Subject=Christmas Card Order" style="color:blue">Marilyn</a>.</p>
								<p>Discover the process Marilyn uses to produce her fine collection of custom Greeting Cards. <a href="javascript:void(getArticle());" onMouseOver="window.status='Design Your Own Christmas Cards';return true" onMouseOut="window.status='';return true" style="color:blue">Click here.</a>
							<p><a href="mailto:msballard@centurytel.net" style="color:blue">Click here</a> to contact Marilyn for pricing.</p>
							<p>&nbsp; </p></td>
					</tr>
					<!-- What a Feast! -->
					<tr> 
						<td width="40%"><p class="cardTitle">What a Feast!</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/feast.jpg', 'Image', 'width=375,height=505'))"><img src="images/cards/thumb/feast.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr> 
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td width="40%"><p class="cardTitle">His Star in the East, Matt:2-2</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/his_star.jpg', 'Image', 'width=620,height=745'))"><img src="images/cards/thumb/his_star.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr> 
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td><p class="cardTitle">Parkbench (Count the Birds)</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/bench.jpg', 'Image', 'width=538,height=377'))"><img src="images/cards/thumb/bench.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr> 
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td><p class="cardTitle">Cardinals Under Oak</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/snow.jpg', 'Image', 'width=438,height=324'))"><img src="images/cards/thumb/snow.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr> 
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td><p class="cardTitle">New Kid on the Block</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/snowman.jpg', 'Image', 'width=367,height=268'))"><img src="images/cards/thumb/snowman.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr> 
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td><p class="cardTitle">Walking with Friends</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/walking.jpg', 'Image', 'width=515,height=401'))"><img src="images/cards/thumb/walking.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr> 
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td><p class="cardTitle">Cardinal in Juniper Tree</p></td>
						<td align="left" style="padding-left:20px"><a href="javascript:void(window.open('images/cards/cardinal.jpg', 'Image', 'width=380,height=510'))"><img src="images/cards/thumb/cardinal.jpg" border="0" width="300" alt=" Copyright &copy; 2004 - 2005 Marilyn Speck Ballard." /></a></td>
					</tr>
					<tr>
						<td colspan="2">&nbsp; </td>
					</tr>
					<tr> 
						<td colspan="2">
						<!--
						<table border="1" bordercolor="#CCCCCC" cellspacing="0"
						style="font:9pt sans-serif;" align="center">
								<tr> 
									<td colspan="2" width="49%"><a name="pricing"></a><strong>5&frac12;" x 8&frac12;" 
										cards with 5x7 image single card (POSTCARD), to include envelopes.</strong></td>
									<td colspan="2" width="49%"><strong>5&frac12;" x 8&frac12;" 
										Single Fold cards, no verse, and to include envelopes.</strong></td>
								</tr>
								<tr align="center"> 
									<td>Quantity</td>
									<td>Price</td>
									<td>Quantity</td>
									<td>Price</td>
								</tr>
								<tr align="center"> 
									<td>50</td>
									<td>$54.60</td>
									<td>50</td>
									<td>$79.00</td>
								</tr>
								<tr align="center"> 
									<td>100</td>
									<td>$86.60</td>
									<td>75</td>
									<td>$118.50</td>
								</tr>
								<tr align="center"> 
									<td>150</td>
									<td>$126.10<font color="#FF0000"><strong>*</strong></font></td>
									<td>100</td>
									<td>$156.00<font color="#FF0000"><strong>*</strong></font></td>
								</tr>
								<tr align="center"> 
									<td>200</td>
									<td>$153.60<font color="#FF0000"><strong>*</strong></font></td>
									<td>150</td>
									<td>$204.00<font color="#FF0000"><strong>*</strong></font></td>
								</tr>
								<tr align="center"> 
									<td colspan="2">&nbsp; </td>
									<td>200</td>
									<td>$272.00<font color="#FF0000"><strong>*</strong></font></td>
								</tr>
								<tr> 
									<td colspan="4"><font color="#FF0000"><strong>*</strong></font> 
										<em>denotes extra postage will apply.</em></td>
								</tr>
								<tr> 
									<td colspan="4">Verses may be printed for an additional $ .15 
										per card. Black ink. Colored ink is $ .30 per card. Machine 
										scoring for folding is an additional $30.00 up to 450.</td>
								</tr>
							</table>
							-->
							</td>
					</tr>
					<tr> 
						<td colspan="2"><p>&nbsp; </p></td>
					</tr>
				</table></td>
		</tr>
<?php

include('include/footer.inc');

?>


</div>
</body>
</html>
